======================================
Identification of Trust (Common files)
======================================

This contains the files common to multiple implementations of the
Identification of Trust microsite. It does not depend upon a specific
framework, and it does not implement a website on its own.
