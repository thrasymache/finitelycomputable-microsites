=======================
Identification of Trust
=======================

This is the implementation of the Identification of Trust microsite.

Installation
INSTALLED_APPS += 'id_trust.apps.IdTrustConfig'
urlpatterns += path('identification_of_trust/', include('id_trust.urls'))


