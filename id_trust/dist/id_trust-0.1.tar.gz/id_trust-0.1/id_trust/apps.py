from django.apps import AppConfig


class IdTrustConfig(AppConfig):
    name = 'id_trust'
