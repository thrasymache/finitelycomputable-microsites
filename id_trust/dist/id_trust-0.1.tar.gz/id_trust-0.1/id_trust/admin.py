from django.contrib import admin

from .models import Interaction, Exchange

admin.site.register(Interaction)
admin.site.register(Exchange)
